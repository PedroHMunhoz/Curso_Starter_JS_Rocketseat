//Template Literals

const nome = "Pedro";
const idade = 28;

//É possível trocar valores em uma string usando template literals
//Para isso a string deve estar englobada em CRASE e onde desejamos substituir os valores deve-se
//usar ${variavel}, dessa forma será dado replace no texto pelo valor da variável
console.log(`Meu nome é ${nome} e eu tenho ${idade} anos`);
