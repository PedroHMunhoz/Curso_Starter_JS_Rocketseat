// 6º Exercício
// Converta o seguinte trecho de código utilizando Template Literals:
const usuario = "Diego";
const idade = 23;

//Console com concatenação
console.log("O usuário " + usuario + " possui " + idade + " anos");

//Console com Template Literals
console.log(`O usuário ${usuario} possui ${idade} anos`);
